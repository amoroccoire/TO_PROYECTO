#include "userfilerepository.h"

UserFileRepository::UserFileRepository() {

}

User* UserFileRepository::createUser(User *user) {

}

bool UserFileRepository::containUser(User *user) {

}

User* UserFileRepository::verifyUser(User *user) {

}

void UserFileRepository::setNameFile(const std::string file = "") {
    this->file = file;
}




